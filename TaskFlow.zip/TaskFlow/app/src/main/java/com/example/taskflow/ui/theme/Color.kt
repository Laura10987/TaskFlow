package com.example.taskflow.ui.theme

import androidx.compose.ui.graphics.Color

val AzulFuerte = Color(0xFF3F51B5)
val AmarilloMostaza = Color(0xFFFFB300)
val FondoClaro = Color(0xFFFAFAFA)
val TextoOscuro = Color(0xFF212121)